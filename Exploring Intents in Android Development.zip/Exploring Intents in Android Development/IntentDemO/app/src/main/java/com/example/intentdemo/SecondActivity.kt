package com.yourpackagename

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

class SecondActivity : AppCompatActivity() {
    private lateinit var displayText: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_second)

        displayText = findViewById(R.id.displayText)

        val receivedText = intent.getStringExtra("user_input")
        displayText.text = receivedText

        findViewById<Button>(R.id.btnSendResult).setOnClickListener {
            val resultIntent = Intent(this, ResultActivity::class.java)
            startActivityForResult(resultIntent, 100)
        }
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == 100 && resultCode == Activity.RESULT_OK) {
            val result = data?.getStringExtra("result_data")
            displayText.text = "Result: $result"
        }
    }
}
